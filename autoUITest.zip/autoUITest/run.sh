pybot -v ip:http://172.19.242.162 -v port:4723 testSuite/flowTest.robot
